﻿namespace seven {
    public class User {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Admin { get; set; } = 0;
        public int Balance { get; set; } = 0;
    }
}
