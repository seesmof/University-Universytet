﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace dev
{
    public class user
    {
        public string name { get; set; }
        public string password { get; set; }
        public bool isAdmin { get; set; }
    }
}
