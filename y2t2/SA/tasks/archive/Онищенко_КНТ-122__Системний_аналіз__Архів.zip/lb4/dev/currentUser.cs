﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dev
{
    public static class currentUser
    {
        public static string name { get; set; }
        public static string password { get; set; }
        public static bool isAdmin { get; set; }
    }
}
