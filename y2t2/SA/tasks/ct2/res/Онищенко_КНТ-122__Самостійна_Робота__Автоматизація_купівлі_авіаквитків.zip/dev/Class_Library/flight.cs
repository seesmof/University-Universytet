﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Library{
    public class flight{
        public string name { get; set; }
        public int price { get; set; }
        public string date { get; set; }
        public int seats { get; set; }
    }
}