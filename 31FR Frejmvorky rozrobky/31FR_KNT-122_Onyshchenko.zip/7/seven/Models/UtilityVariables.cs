﻿namespace seven {
    public static class UtilityVariables {
        public const string connectionString = "uid=root;pwd=1313;host=localhost;port=3306;database=fr_data";
    }
}
